//package com.polstat.ServicePengumpulan.Controller;
//
//import com.polstat.ServicePengumpulan.DTO.AuthRequest;
//import com.polstat.ServicePengumpulan.DTO.AuthResponse;
//import com.polstat.ServicePengumpulan.DTO.UserDTO;
//import com.polstat.ServicePengumpulan.Entity.UserRole;
//import com.polstat.ServicePengumpulan.Service.AuthService;
//import com.polstat.ServicePengumpulan.Service.UserService;
//import java.util.Set;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/auth")
//public class AuthController {
//
//    @Autowired
//    private AuthService authService;
//    
//     @Autowired
//    private UserService userService; // Pastikan userService di-inject dengan @Autowired
//    
//     private static final Set<String> VALID_ID_PANITIA = Set.of("PANITIA2024_1", "PANITIA2024_2", "PANITIA2024_3",
//             "PANITIA2024_4","PANITIA2024_5");// Valid ID Panitia for Admin
//
//    @PostMapping("/login")
//    public AuthResponse login(@RequestBody AuthRequest authRequest) {
//        return authService.login(authRequest);
//    }
//    @PostMapping("/register")
//public String registerUser(@RequestBody UserDTO userDTO) {
//    if (userDTO.getRole() == UserRole.ADMIN) {
//        if (userDTO.getIdPanitia() == null || !VALID_ID_PANITIA.contains(userDTO.getIdPanitia())) {
//            return "Invalid ID Panitia";
//        }
//    } else if (userDTO.getRole() == UserRole.SISWA) {
//        if (userDTO.getNim() == null) {
//            return "NIM is required for Siswa";
//        }
//    }
//
//    userService.registerUser(userDTO);
//    return "User registered successfully";
//}
//
//}
package com.polstat.ServicePengumpulan.Controller;

import com.polstat.ServicePengumpulan.DTO.AuthRequest;
import com.polstat.ServicePengumpulan.DTO.AuthResponse;
import com.polstat.ServicePengumpulan.DTO.UserDTO;
import com.polstat.ServicePengumpulan.Entity.UserRole;
import com.polstat.ServicePengumpulan.Service.AuthService;
import com.polstat.ServicePengumpulan.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private UserService userService;

    private static final Set<String> VALID_ID_PANITIA = Set.of(
            "PANITIA2024_1", "PANITIA2024_2", "PANITIA2024_3", "PANITIA2024_4", "PANITIA2024_5"
    ); // Daftar ID Panitia yang valid untuk role ADMIN

    /**
     * Endpoint untuk login, menerima baik 'nim' untuk SISWA maupun 'id_panitia' untuk ADMIN
     * @param authRequest
     * @return 
     */
    @PostMapping("/login")
    public AuthResponse login(@RequestBody AuthRequest authRequest) {
        return authService.login(authRequest);
    }

    /**
     * Endpoint untuk registrasi user, memeriksa ID Panitia untuk ADMIN dan NIM untuk SISWA
     * @param userDTO
     * @return 
     */
    @PostMapping("/register")
    public String registerUser(@RequestBody UserDTO userDTO) {
        if (userDTO.getRole() == UserRole.ADMIN) {
            // Validasi bahwa ADMIN memiliki ID Panitia yang valid
            if (userDTO.getIdPanitia() == null || !VALID_ID_PANITIA.contains(userDTO.getIdPanitia())) {
                return "Invalid ID Panitia";
            }
        } else if (userDTO.getRole() == UserRole.SISWA) {
            // Validasi bahwa SISWA memiliki NIM yang valid
            if (userDTO.getNim() == null) {
                return "NIM is required for Siswa";
            }
        } else {
            return "Invalid role specified";
        }

        // Jika validasi berhasil, lanjutkan dengan registrasi user
        userService.registerUser(userDTO);
        return "User registered successfully";
    }
}
