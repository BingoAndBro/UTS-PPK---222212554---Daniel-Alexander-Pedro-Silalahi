package com.polstat.ServicePengumpulan.Controller;

import com.polstat.ServicePengumpulan.DTO.PKKMBInfoDTO;
import com.polstat.ServicePengumpulan.DTO.TaskDTO;
import com.polstat.ServicePengumpulan.Security.AuthenticatedUserService;
import com.polstat.ServicePengumpulan.Service.SiswaService;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/siswa")
public class SiswaController {

    @Autowired
    private SiswaService siswaService;
    
     @Autowired
    private AuthenticatedUserService authenticatedUserService;

    @GetMapping("/pkkmbinfos")
    public List<PKKMBInfoDTO> getPKKMBInfo() {
        return siswaService.getPKKMBInfo();
    }

 @GetMapping("/tasks/{nim}")
    public List<TaskDTO> getTasksByNim(@PathVariable String nim) {
        // Validasi apakah `nim` dalam URL sama dengan `nim` dari siswa yang login
        String currentUserNim = authenticatedUserService.getCurrentUserNim();
        if (!nim.equals(currentUserNim)) {
            throw new SecurityException("Access Denied: You can only access your own tasks.");
        }
        return siswaService.getTasksByNim(nim);
    }
    
    

//    @PutMapping("/task/{id}/submit")
//    public TaskDTO submitTask(@PathVariable Long id) {
//        return siswaService.submitTask(id);
//    }
    
    
    @PutMapping("/task/{id}/submit")
    public TaskDTO submitTask(@PathVariable Long id, @RequestParam("file") MultipartFile file) throws IOException {
        return siswaService.submitTask(id, file);
    }
}
