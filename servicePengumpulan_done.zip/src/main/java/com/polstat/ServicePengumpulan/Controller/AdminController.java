package com.polstat.ServicePengumpulan.Controller;

import com.polstat.ServicePengumpulan.DTO.*;
import com.polstat.ServicePengumpulan.Entity.Task;
import com.polstat.ServicePengumpulan.Repository.TaskRepository;
import com.polstat.ServicePengumpulan.Service.AdminService;
import java.io.File;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;
    
        @Autowired
    private TaskRepository taskRepository;  // Inject taskRepository

    @PostMapping("/user")
    public UserDTO createUser(@RequestBody UserDTO userDTO) {
        return adminService.createUser(userDTO);
    }

    @PutMapping("/user/{id}")
    public UserDTO updateUser(@PathVariable Long id, @RequestBody UserDTO userDTO) {
        return adminService.updateUser(id, userDTO);
    }

    @DeleteMapping("/user/{id}")
    public void deleteUser(@PathVariable Long id) {
        adminService.deleteUser(id);
    }

    @GetMapping("/users")
    public List<UserDTO> getAllUsers() {
        return adminService.getAllUsers();
    }

    @PostMapping("/task")
    public TaskDTO createTask(@RequestBody TaskDTO taskDTO) {
        return adminService.createTask(taskDTO);
    }

    @PutMapping("/task/{id}")
    public TaskDTO updateTask(@PathVariable Long id, @RequestBody TaskDTO taskDTO) {
        return adminService.updateTask(id, taskDTO);
    }

    @DeleteMapping("/task/{id}")
    public void deleteTask(@PathVariable Long id) {
        adminService.deleteTask(id);
    }

    @GetMapping("/tasks")
    public List<TaskDTO> getAllTasks() {
        return adminService.getAllTasks();
    }

    @PostMapping("/pkkmbinfo")
    public PKKMBInfoDTO createPKKMBInfo(@RequestBody PKKMBInfoDTO pkkmbInfoDTO) {
        return adminService.createPKKMBInfo(pkkmbInfoDTO);
    }

    @PutMapping("/pkkmbinfo/{id}")
    public PKKMBInfoDTO updatePKKMBInfo(@PathVariable Long id, @RequestBody PKKMBInfoDTO pkkmbInfoDTO) {
        return adminService.updatePKKMBInfo(id, pkkmbInfoDTO);
    }

    @DeleteMapping("/pkkmbinfo/{id}")
    public void deletePKKMBInfo(@PathVariable Long id) {
        adminService.deletePKKMBInfo(id);
    }

    @GetMapping("/pkkmbinfos")
    public List<PKKMBInfoDTO> getAllPKKMBInfo() {
        return adminService.getAllPKKMBInfo();
    }
    
    // Endpoint for admins to download a task file
    @GetMapping("/task/{id}/file")
    public ResponseEntity<FileSystemResource> downloadTaskFile(@PathVariable Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        File file = new File(task.getFilePath());
        if (!file.exists()) {
            return ResponseEntity.notFound().build();
        }

        // Prepare file for download
        FileSystemResource resource = new FileSystemResource(file);
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.getName());

        return new ResponseEntity<>(resource, headers, HttpStatus.OK);
    }
}
