package com.polstat.ServicePengumpulan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicePengumpulanApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServicePengumpulanApplication.class, args);
    }
}
