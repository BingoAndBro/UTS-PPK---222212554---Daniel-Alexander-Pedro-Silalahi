package com.polstat.ServicePengumpulan.Entity;

public enum UserRole {
    ADMIN,
    SISWA
}
