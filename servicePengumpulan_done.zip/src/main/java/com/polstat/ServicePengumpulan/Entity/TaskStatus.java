package com.polstat.ServicePengumpulan.Entity;

public enum TaskStatus {
    TEPAT_WAKTU,
    TERLAMBAT,
    BELUM_KUMPUL
}
