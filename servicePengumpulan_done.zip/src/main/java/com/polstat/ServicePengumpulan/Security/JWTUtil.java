//package com.polstat.ServicePengumpulan.Security;
//
//import io.jsonwebtoken.*;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//
//import java.util.Date;
//import java.util.function.Function;
//
//@Component
//public class JWTUtil {
//
//    @Value("${jwt.secret}")
//    private String secret;
//
//    @Value("${jwt.expiration}")
//    private long expiration;
//
//    // Generate a token with nim and role as claims
//    public String generateToken(String nim, String role) {
//        return Jwts.builder()
//                .setSubject(nim)
//                .claim("role", role)
//                .setIssuedAt(new Date())
//                .setExpiration(new Date(System.currentTimeMillis() + expiration))
//                .signWith(SignatureAlgorithm.HS512, secret)
//                .compact();
//    }
//
//    // Extract nim/username from token
//    public String extractUsername(String token) {
//        return extractClaim(token, Claims::getSubject);
//    }
//
//    // Extract role from token
//    public String extractRole(String token) {
//        Claims claims = extractAllClaims(token);
//        return claims.get("role", String.class);
//    }
//
//    // General method to extract any claim from token
//    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
//        Claims claims = extractAllClaims(token);
//        return claimsResolver.apply(claims);
//    }
//
//    // Extract all claims, with handling for invalid tokens
//    private Claims extractAllClaims(String token) {
//        try {
//            return Jwts.parser()
//                    .setSigningKey(secret)
//                    .parseClaimsJws(token)
//                    .getBody();
//        } catch (ExpiredJwtException e) {
//            throw new RuntimeException("JWT token has expired", e);
//        } catch (UnsupportedJwtException e) {
//            throw new RuntimeException("JWT token is unsupported", e);
//        } catch (MalformedJwtException e) {
//            throw new RuntimeException("JWT token is malformed", e);
//        } catch (SignatureException e) {
//            throw new RuntimeException("JWT token signature validation failed", e);
//        } catch (IllegalArgumentException e) {
//            throw new RuntimeException("JWT token is empty or null", e);
//        }
//    }
//
//    // Check if token is expired
//    public boolean isTokenExpired(String token) {
//        return extractExpiration(token).before(new Date());
//    }
//
//    // Extract expiration date from token
//    public Date extractExpiration(String token) {
//        return extractClaim(token, Claims::getExpiration);
//    }
//
//    // Validate token by checking the username and expiration
//    public boolean validateToken(String token, String nim) {
//        String username = extractUsername(token);
//        return (username.equals(nim) && !isTokenExpired(token));
//    }
//}

package com.polstat.ServicePengumpulan.Security;

import io.jsonwebtoken.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.util.Date;
import java.util.function.Function;

@Component
public class JWTUtil {

    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.expiration}")
    private long expiration;

//    public String generateToken(String identifier, String role) {
//        return Jwts.builder()
//                .setSubject(identifier) // Subject can be either 'nim' or 'id_panitia'
//                .claim("role", role)
//                .setIssuedAt(new Date())
//                .setExpiration(new Date(System.currentTimeMillis() + expiration))
//                .signWith(SignatureAlgorithm.HS512, secret)
//                .compact();
//    }
    
    public String generateToken(String identifier, String role) {
        JwtBuilder builder = Jwts.builder()
                .claim("role", role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(SignatureAlgorithm.HS512, secret);

        if ("SISWA".equals(role)) {
            builder.setSubject(identifier); // `identifier` as `nim`
        } else {
//            builder.setSubject("admin_" + identifier);
               builder.setSubject("admin"); // Static subject for ADMIN
        }

        return builder.compact();
    }

    public String extractIdentifier(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public String extractRole(String token) {
        Claims claims = extractAllClaims(token);
        return claims.get("role", String.class);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
    }

    public boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    public boolean validateToken(String token, String identifier) {
        String extractedIdentifier = extractIdentifier(token);
        return (extractedIdentifier.equals(identifier) && !isTokenExpired(token));
    }
}

