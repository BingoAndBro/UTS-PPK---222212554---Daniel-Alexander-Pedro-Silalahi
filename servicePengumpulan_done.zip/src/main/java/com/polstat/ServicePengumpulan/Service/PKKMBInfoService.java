//package com.polstat.ServicePengumpulan.Service;
//
//import com.polstat.ServicePengumpulan.DTO.PKKMBInfoDTO;
//import com.polstat.ServicePengumpulan.Entity.PKKMBInfo;
//import com.polstat.ServicePengumpulan.Mapper.PKKMBInfoMapper;
//import com.polstat.ServicePengumpulan.Repository.PKKMBInfoRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//@Service
//public class PKKMBInfoService {
//
//    @Autowired
//    private PKKMBInfoRepository pkkmbInfoRepository;
//
//    @Autowired
//    private PKKMBInfoMapper pkkmbInfoMapper;
//
//    public PKKMBInfoDTO savePKKMBInfo(PKKMBInfoDTO pkkmbInfoDTO) {
//        PKKMBInfo pkkmbInfo = pkkmbInfoMapper.toPKKMBInfo(pkkmbInfoDTO);
//        PKKMBInfo savedInfo = pkkmbInfoRepository.save(pkkmbInfo);
//        return pkkmbInfoMapper.toPKKMBInfoDTO(savedInfo);
//    }
//
//    public List<PKKMBInfoDTO> getAllPKKMBInfo() {
//        return pkkmbInfoRepository.findAll()
//                .stream()
//                .map(pkkmbInfoMapper::toPKKMBInfoDTO)
//                .collect(Collectors.toList());
//    }
//
//    public Optional<PKKMBInfoDTO> getPKKMBInfoById(Long id) {
//        return pkkmbInfoRepository.findById(id).map(pkkmbInfoMapper::toPKKMBInfoDTO);
//    }
//
//    public void deletePKKMBInfoById(Long id) {
//        pkkmbInfoRepository.deleteById(id);
//    }
//}
