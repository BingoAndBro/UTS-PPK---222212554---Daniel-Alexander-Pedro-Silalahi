//package com.polstat.ServicePengumpulan.Service;
//
//import com.polstat.ServicePengumpulan.DTO.TaskDTO;
//import com.polstat.ServicePengumpulan.Entity.Task;
//import com.polstat.ServicePengumpulan.Mapper.TaskMapper;
//import com.polstat.ServicePengumpulan.Repository.TaskRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//@Service
//public class TaskService {
//
//    @Autowired
//    private TaskRepository taskRepository;
//
//    @Autowired
//    private TaskMapper taskMapper;
//
//    public TaskDTO saveTask(TaskDTO taskDTO) {
//        Task task = taskMapper.toTask(taskDTO);
//        Task savedTask = taskRepository.save(task);
//        return taskMapper.toTaskDTO(savedTask);
//    }
//
//    public List<TaskDTO> getAllTasks() {
//        return taskRepository.findAll()
//                .stream()
//                .map(taskMapper::toTaskDTO)
//                .collect(Collectors.toList());
//    }
//
//    public Optional<TaskDTO> getTaskById(Long id) {
//        return taskRepository.findById(id).map(taskMapper::toTaskDTO);
//    }
//
//    public void deleteTaskById(Long id) {
//        taskRepository.deleteById(id);
//    }
//}
