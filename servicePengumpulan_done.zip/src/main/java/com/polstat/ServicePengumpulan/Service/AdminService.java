package com.polstat.ServicePengumpulan.Service;

import com.polstat.ServicePengumpulan.DTO.*;
import com.polstat.ServicePengumpulan.Entity.*;
import com.polstat.ServicePengumpulan.Mapper.*;
import com.polstat.ServicePengumpulan.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdminService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private PKKMBInfoRepository pkkmbInfoRepository;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private TaskMapper taskMapper;

    @Autowired
    private PKKMBInfoMapper pkkmbInfoMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public UserDTO createUser(UserDTO userDTO) {
        User user = userMapper.toEntity(userDTO);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userMapper.toDTO(userRepository.save(user));
    }

    public UserDTO updateUser(Long id, UserDTO userDTO) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
        user.setNim(userDTO.getNim());
        user.setRole(userDTO.getRole());
        user.setPassword(passwordEncoder.encode(userDTO.getPassword())); // Update password jika diperlukan
        return userMapper.toDTO(userRepository.save(user));
    }

    public void deleteUser(Long id) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
        if (user.getRole() == UserRole.SISWA) {
            userRepository.delete(user);
        } else {
            throw new RuntimeException("Admin cannot delete another admin");
        }
    }

    public List<UserDTO> getAllUsers() {
        return userRepository.findAll().stream()
                .map(userMapper::toDTO)
                .collect(Collectors.toList());
    }

  // AdminService.java

//public TaskDTO createTask(TaskDTO taskDTO) {
//    Task task = Task.builder()
//            .title(taskDTO.getTitle())
//            .description(taskDTO.getDescription())
//            .status(TaskStatus.BELUM_KUMPUL)  // Initial status or based on input
//            .assignedTo(userRepository.findById(taskDTO.getAssignedToUserId())
//                      .orElseThrow(() -> new RuntimeException("User not found")))
//            .build();
//    
//    taskRepository.save(task);
//    return taskDTO;  // Or map back to TaskDTO as needed
//}
    
        public TaskDTO createTask(TaskDTO taskDTO) {
        Task task = taskMapper.toEntity(taskDTO);
        taskRepository.save(task);
        return taskMapper.toDTO(task);
    }


    public TaskDTO updateTask(Long id, TaskDTO taskDTO) {
        Task task = taskRepository.findById(id).orElseThrow(() -> new RuntimeException("Task not found"));
        task.setTitle(taskDTO.getTitle());
        task.setDescription(taskDTO.getDescription());
        task.setStatus(taskDTO.getStatus());
        return taskMapper.toDTO(taskRepository.save(task));
    }

    public void deleteTask(Long id) {
        taskRepository.deleteById(id);
    }

    public List<TaskDTO> getAllTasks() {
        return taskRepository.findAll().stream()
                .map(taskMapper::toDTO)
                .collect(Collectors.toList());
    }

    public PKKMBInfoDTO createPKKMBInfo(PKKMBInfoDTO pkkmbInfoDTO) {
        PKKMBInfo pkkmbInfo = pkkmbInfoMapper.toEntity(pkkmbInfoDTO);
        return pkkmbInfoMapper.toDTO(pkkmbInfoRepository.save(pkkmbInfo));
    }

    public PKKMBInfoDTO updatePKKMBInfo(Long id, PKKMBInfoDTO pkkmbInfoDTO) {
        PKKMBInfo pkkmbInfo = pkkmbInfoRepository.findById(id).orElseThrow(() -> new RuntimeException("PKKMBInfo not found"));
        pkkmbInfo.setTitle(pkkmbInfoDTO.getTitle());
        pkkmbInfo.setContent(pkkmbInfoDTO.getContent());
        return pkkmbInfoMapper.toDTO(pkkmbInfoRepository.save(pkkmbInfo));
    }

    public void deletePKKMBInfo(Long id) {
        pkkmbInfoRepository.deleteById(id);
    }

    public List<PKKMBInfoDTO> getAllPKKMBInfo() {
        return pkkmbInfoRepository.findAll().stream()
                .map(pkkmbInfoMapper::toDTO)
                .collect(Collectors.toList());
    }
}
