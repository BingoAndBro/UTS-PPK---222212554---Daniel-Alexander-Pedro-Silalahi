//package com.polstat.ServicePengumpulan;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest // Anotasi ini memuat seluruh konteks aplikasi
//public class ServicePengumpulanApplicationTest {
//
//    @Test
//    public void contextLoads() {
//        // Pengujian ini hanya memastikan bahwa konteks Spring Boot bisa dimuat tanpa error
//    }
//}
